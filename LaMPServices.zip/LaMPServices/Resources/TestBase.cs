﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Xml.Serialization;

namespace LaMPServices.Resources
{

    public abstract class TestBase
    {
        #region Properties
        public Int32 TestId { get; set; }

       public String Term { get; set; }

        #endregion

    }//end keywordBase

    public class Test:TestBase
    {
        #region Constructors
        public Test()
        {
            this.TestId = -1;
            this.Term = string.Empty;
        }
        #endregion
    }//end Test
    
  }//end namespace